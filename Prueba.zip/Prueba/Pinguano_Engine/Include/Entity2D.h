#pragma once
#include "Entity.h"

using namespace Entity;

class Entity2D : public Entity
{
	public:
	

};

